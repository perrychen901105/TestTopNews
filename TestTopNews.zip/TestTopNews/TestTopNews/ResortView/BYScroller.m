//
//  BYScroller.m
//  BYDailyNews
//
//  Created by bassamyan on 15/3/8.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "BYScroller.h"
#import "ResortViewHeader.h"
@implementation BYScroller

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor redColor];
    }
    return self;
}

@end
