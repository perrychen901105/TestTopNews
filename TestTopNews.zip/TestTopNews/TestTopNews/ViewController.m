//
//  ViewController.m
//  TestTopNews
//
//  Created by PerryChen on 12/28/15.
//  Copyright © 2015 PerryChen. All rights reserved.
//

#import "ViewController.h"
#import "ResortViewController.h"
#import "BYListBar.h"
#import "InfoDetailViewController.h"

#define kListBarH 30
#define kArrowW 40
#define kAnimationTime 0.8

@interface ViewController () <UIScrollViewDelegate>
@property (nonatomic,strong) BYListBar *listBar;
@property (nonatomic,strong) UIButton *btnAdd;
@property (nonatomic,strong) UIScrollView *mainScroller;
@property (nonatomic,strong) NSMutableArray *arrTop;
@property (nonatomic,strong) NSMutableArray *arrCenter;
@property (nonatomic,strong) NSMutableArray *arrBottom;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.arrTop = [[NSMutableArray alloc] initWithArray:@[@"TOP1",@"TOP2",@"TOP3",@"TOP4",@"TOP5",@"TOP6",@"TOP7",@"TOP8"]];
    self.arrCenter = [[NSMutableArray alloc] initWithArray:@[@"CENTER1",@"CENTER2",@"CENTER3",@"CENTER4",@"CENTER5",@"CENTER6",@"CENTER7",@"CENTER8",@"CENTER9",@"CENTER10",@"CENTER11",@"CENTER12",@"CENTER13",@"CENTER14",@"CENTER15",@"CENTER16",@"CENTER17",@"CENTER18",@"CENTER19",@"CENTER20"]];
    self.arrBottom = [[NSMutableArray alloc] initWithArray:@[@"BOTTOM1",@"BOTTOM2",@"BOTTOM3",@"BOTTOM4",@"BOTTOM5",@"BOTTOM6",@"BOTTOM7",@"BOTTOM8",@"BOTTOM9"]];

    __weak typeof(self) unself = self;
    self.listBar = [[BYListBar alloc] initWithFrame:CGRectMake(0, 64.0f, kScreenW-kArrowW, kListBarH)];
    self.listBar.visibleItemList = self.arrTop;

    self.listBar.listBarItemClickBlock = ^(NSString *itemName , NSInteger itemIndex){
//        [unself.detailsList itemRespondFromListBarClickWithItemName:itemName];
        //添加scrollview
        
        //移动到该位置
        unself.mainScroller.contentOffset =  CGPointMake(itemIndex * unself.mainScroller.frame.size.width, 0);
    };
    self.listBar.listBarAddItemBlock = ^(NSString *itemName, NSInteger itemIndex) {
        NSLog(@"the item name add is %@, index is %d",itemName,itemIndex);
        unself.mainScroller.contentSize = CGSizeMake(kScreenW*unself.arrTop.count,unself.mainScroller.frame.size.height);
        [unself addScrollViewWithItemName:itemName index:itemIndex];
    };
    self.listBar.listBarDeleteItemBlock = ^(NSString *itemName, NSInteger itemIndex) {
        NSLog(@"the item name delete is %@, index is %d",itemName,itemIndex);

        [unself removeScrollViewWithItemName:itemName index:itemIndex];
        
    };
    [self.view addSubview:self.listBar];
    
    if (!self.btnAdd) {
        self.btnAdd = [UIButton buttonWithType:UIButtonTypeCustom];
        self.btnAdd.frame = CGRectMake(kScreenW-kArrowW, 64.0f, kArrowW, kListBarH);
        [self.btnAdd addTarget:self
                        action:@selector(btnActionPush:) forControlEvents:UIControlEventTouchUpInside];
        [self.btnAdd setBackgroundColor:[UIColor blueColor]];
        [self.view addSubview:self.btnAdd];
    }
    
    NSLog(@"the view frame is %@",NSStringFromCGRect(self.view.frame));
    if (!self.mainScroller) {
        self.mainScroller = [[UIScrollView alloc] initWithFrame:CGRectMake(0, kListBarH+64.0f, kScreenW , self.view.frame.size.height-kListBarH-64.0f)];
        self.mainScroller.backgroundColor = [UIColor yellowColor];
        self.mainScroller.bounces = NO;
        self.mainScroller.pagingEnabled = YES;
        self.mainScroller.showsHorizontalScrollIndicator = NO;
        self.mainScroller.showsVerticalScrollIndicator = NO;
        self.mainScroller.delegate = self;
        self.mainScroller.contentSize = CGSizeMake(kScreenW*self.arrTop.count,self.mainScroller.frame.size.height);
        [self.view insertSubview:self.mainScroller atIndex:0];
        for (int i = 0; i < self.arrTop.count; i++) {
            [self addScrollViewWithItemName:self.arrTop[i] index:i];
        }
        
    }
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnActionPush:(id)sender {
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionFade;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    ResortViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ResortViewController"];
    vc.listBar = self.listBar;
    vc.listTop = self.arrTop;
    vc.listBottom = self.arrCenter;
    vc.listBottomTwo = self.arrBottom;
    [self.navigationController pushViewController:vc animated:NO];
}

-(void)addScrollViewWithItemName:(NSString *)itemName index:(NSInteger)index{
    InfoDetailViewController *detailVC = (InfoDetailViewController*)[[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"InfoDetailViewController"];
    detailVC.view.frame = CGRectMake(index * self.mainScroller.frame.size.width, 0, self.mainScroller.frame.size.width, self.mainScroller.frame.size.height);
    detailVC.lblTitle.text = [NSString stringWithFormat:@"%ld",index];
    [self addChildViewController:detailVC];
    
    detailVC.view.tag = index;
    [self.mainScroller addSubview:detailVC.view];
    
}

- (void)loopSubViews
{
    for (int i = 0; i < self.childViewControllers.count; i++) {
        InfoDetailViewController *vcD = self.childViewControllers[i];
        vcD.view.frame = CGRectMake(i * self.mainScroller.frame.size.width, 0, self.mainScroller.frame.size.width, self.mainScroller.frame.size.height);
    }
}

- (void)removeScrollViewWithItemName:(NSString *)itemName index:(NSInteger)index {
    for (UIView *sview in self.mainScroller.subviews) {
        if (sview.tag == index) {
            [sview removeFromSuperview];
            break;
        }
    }
    InfoDetailViewController *vcD = self.childViewControllers[index];
    [vcD removeFromParentViewController];
    [self loopSubViews];
    self.mainScroller.contentSize = CGSizeMake(kScreenW*self.arrTop.count,self.mainScroller.frame.size.height);
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    [self.listBar itemClickByScrollerWithIndex:scrollView.contentOffset.x / self.mainScroller.frame.size.width];
}

@end
